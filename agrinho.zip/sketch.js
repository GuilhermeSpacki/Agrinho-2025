// Definindo variáveis globais
let jardineiro;
let plantas = [];
let temperatura = 10; // Temperatura inicial
let totalArvores = 0; // Contador de árvores plantadas

function setup() {
  createCanvas(600, 400);
  jardineiro = new Jardineiro(width / 2, height - 50);
}

function draw() {
  // Usando map() para ajustar a cor de fundo com base no número de árvores plantadas
  let corFundo = lerpColor(color(217, 112, 26), color(219, 239, 208),
    map(totalArvores, 0, 100, 0, 1));
  background(corFundo);

  mostrarInformacoes();

  temperatura += 0.05; // A temperatura aumenta lentamente

  jardineiro.atualizar();
  jardineiro.mostrar();

  // Verifica se o jogo acabou
  verificarFimDeJogo();

  // Atualiza as árvores plantadas
  plantas.map((arvore) => arvore.mostrar());
}
// Função para mostrar as informações na tela
function mostrarInformacoes() {
  textSize(16);
  fill(0);
  text(`Temperatura: ${Math.round(temperatura)}°C`, 10, 20);
  text(`Árvores Plantadas: ${totalArvores}`, 10, 40);
}

// Função para verificar o fim do jogo (se a temperatura for alta demais)
function verificarFimDeJogo() {
  if (temperatura > 50) {
    fill(255, 0, 0);
    textSize(32);
    textAlign(CENTER);
    text('FIM DE JOGO - Temperatura muito alta!', width / 2, height / 2);
    noLoop(); // Para o jogo
  }
}

// Classe do Jardineiro
class Jardineiro {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.tamanho = 30;
    this.cor = color(0, 128, 0);
  }

  atualizar() {
    // A interação com as teclas "esquerda" e "direita" para mover o jardineiro
    if (keyIsDown(LEFT_ARROW)) {
      this.x -= 3;
    }
    if (keyIsDown(RIGHT_ARROW)) {
      this.x += 3;
    }
if (keyIsDown(UP_ARROW )) {
      this.y -= 3;
    }
    if (keyIsDown(DOWN_ARROW )) {
      this.y += 3;
    }

    // A interação com a tecla "espaço" para plantar uma árvore
    if (keyIsDown(32)) {
      this.plantarArvore();
    }
  }

  mostrar() {
    fill(this.cor);
    ellipse(this.x, this.y, this.tamanho, this.tamanho); // Corpo do jardineiro
  }

  // Função para plantar uma árvore
  plantarArvore() {
    if (frameCount % 30 === 0) { // Controla a frequência de plantio
      let arvore = new Arvore(this.x, this.y);
      plantas.push(arvore);
      totalArvores++;
    }
  }
}

// Classe da Árvore
class Arvore {
  constructor(x, y) {
    this.x = x;
    this.y = y - 40; // A árvore começa um pouco acima do jardineiro
    this.tamanho = random(20, 40); // Tamanho variável para as árvores
    this.crescendo = true;
  }

  mostrar() {
    if (this.crescendo && temperatura <= 50) {
      // A árvore cresce dependendo da temperatura
      this.tamanho += 0.2;
    }

    // Cor da árvore depende da temperatura
    if (temperatura > 35) {
      fill(139, 69, 19); // Tronco marrom se estiver muito quente
    } else {
      fill(34, 139, 34); // Cor normal de uma árvore verde
    }

    ellipse(this.x, this.y, this.tamanho, this.tamanho);
  }
}
